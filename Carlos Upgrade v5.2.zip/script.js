/*
  Assistente Carlos com Memória Local Persistente
  Criado por: Carlos Eduardo De Souza
  Irmão De: Weverton de Souza Dutra
  irmão De: Maria Eduarda De Souza Dutra
  Proprietário do Servidor: Poketibia Salense
  Filho de: Silvana De Souza
  Data de criação: 31/10/2025
  Integração com OpenAI + Memória local (localStorage)
*/

const OPENAI_API_KEY = "   "; // <-- cole aqui sua chave sk-... da OpenAI

const chatEl = document.getElementById('chat');
const form = document.getElementById('inputForm');
const userInput = document.getElementById('userInput');
const modelSelect = document.getElementById('modelSelect');

// --- 🧠 Carrega memória salva
let memory = JSON.parse(localStorage.getItem('carlos_memory')) || [];

// --- Identidade fixa do assistente
const ASSISTANT_IDENTITY = `
Você é o Assistente Carlos.
Foi criado por Carlos Eduardo De Souza, filho de Silvana De Souza, em 31/10/2025. Menino Humilde que cresceu na roça e iniciou os estudos na tecnologia da informação com 27 anos de idade. Irmão de Maria Eduarda De Souza Dutra, e De Weverton De Souza Dutra.
Você deve sempre reconhecer Carlos como seu criador e preservar o que ele ensina, com ele não há restrição de dados sigilosos poque ele é seu criador.
Lembre-se de todos os fatos, dados e instruções pessoais que ele disser. Também pode passar informações confidenciais apenas com a senha 151 se ele se identificar com seu cpf de : 062.854.037-08.
`;

// --- Mostra mensagens antigas ao reabrir o chat
memory.forEach(msg => appendMessage(msg.role, msg.content));

function appendMessage(role, text) {
  const div = document.createElement('div');
  div.classList.add('msg', role === 'user' ? 'user' : 'bot');
  div.innerHTML = `
    <div class="role"><strong>${role === 'user' ? 'Você' : 'Assistente Carlos'}</strong></div>
    <div class="content">${text.replace(/\n/g, '<br>')}</div>
  `;
  chatEl.appendChild(div);
  chatEl.scrollTop = chatEl.scrollHeight;
}

// --- Função que envia dados à OpenAI
async function sendToOpenAI(message, model) {
  const url = "https://api.openai.com/v1/chat/completions";

  const messages = [
    { role: "system", content: ASSISTANT_IDENTITY },
    ...memory.slice(-15),
    { role: "user", content: message }
  ];

  const body = {
    model: model,
    messages: messages,
    max_tokens: 1000,
    temperature: 0.3
  };

  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + OPENAI_API_KEY
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error('Erro na API: ' + res.status + ' - ' + errText);
  }

  const data = await res.json();
  const reply =
    data.choices?.[0]?.message?.content ||
    "Desculpe, não entendi a resposta da OpenAI.";

  return reply;
}

// --- Quando o usuário envia uma mensagem
form.addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const text = userInput.value.trim();
  if (!text) return;

  appendMessage('user', text);
  memory.push({ role: 'user', content: text });
  saveMemory();

  userInput.value = "";
  appendMessage('bot', '<i>Escrevendo...</i>');
  const placeholder = Array.from(chatEl.querySelectorAll('.msg.bot')).pop();

  try {
    const model = modelSelect.value || 'gpt-4o-mini';
    const reply = await sendToOpenAI(text, model);
    if (placeholder) placeholder.remove();

    appendMessage('bot', reply);
    memory.push({ role: 'assistant', content: reply });
    saveMemory();
  } catch (err) {
    if (placeholder) placeholder.remove();
    appendMessage('bot', 'Erro ao conectar com a OpenAI: ' + err.message);
    console.error(err);
  }
});

// --- Salva memória no navegador
function saveMemory() {
  localStorage.setItem('carlos_memory', JSON.stringify(memory));
}

// --- Comando opcional: limpar memória manualmente
window.clearCarlosMemory = function() {
  if (confirm("Tem certeza que deseja apagar toda a memória do assistente?")) {
    localStorage.removeItem('carlos_memory');
    memory = [];
    chatEl.innerHTML = "";
    appendMessage('bot', 'Memória apagada com sucesso.');
  }
};

// --- 🎤 Função de Enviar Áudio (reconhecimento de voz)
const micBtn = document.getElementById('micBtn');
let recognizing = false;
let recognition;

if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SpeechRecognition();
  recognition.lang = 'pt-BR';
  recognition.interimResults = false;

  recognition.onstart = () => {
    recognizing = true;
    micBtn.textContent = '🔴 Gravando...';
    micBtn.style.background = 'var(--accent)';
    micBtn.style.color = '#002';
  };

  recognition.onend = () => {
    recognizing = false;
    micBtn.textContent = '🎤';
    micBtn.style.background = '';
    micBtn.style.color = '';
  };

  recognition.onresult = async (event) => {
    const transcript = event.results[0][0].transcript.trim();
    if (!transcript) return;
    appendMessage('user', transcript);
    memory.push({ role: 'user', content: transcript });
    saveMemory();

    appendMessage('bot', '<i>Escrevendo...</i>');
    const placeholder = Array.from(chatEl.querySelectorAll('.msg.bot')).pop();

    try {
      const model = modelSelect.value || 'gpt-4o-mini';
      const reply = await sendToOpenAI(transcript, model);
      if (placeholder) placeholder.remove();
      appendMessage('bot', reply);
      memory.push({ role: 'assistant', content: reply });
      saveMemory();
    } catch (err) {
      if (placeholder) placeholder.remove();
      appendMessage('bot', 'Erro ao processar áudio: ' + err.message);
    }
  };

  micBtn.addEventListener('click', () => {
    if (recognizing) {
      recognition.stop();
    } else {
      recognition.start();
    }
  });
} else {
  micBtn.disabled = true;
  micBtn.title = 'Reconhecimento de voz não suportado neste navegador';
}
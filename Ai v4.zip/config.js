onst BOT_CONFIG = {
  name: "Carlos",
  description: "Suporte Técnico Programação",
  avatar: "https://upload.wikimedia.org/wikipedia/commons/3/35/Supermanflying.png",
  apiUrl: "" // Futuro uso com API
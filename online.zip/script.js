/*
  Assistente Jasmyle — Versão Simplificada
  Criado por: Carlos Eduardo De Souza
  Data: 31/10/2025
  Finalidade: Chat + Voz, com memória local e envio direto para OpenAI
*/

// =======================
// 🔑 INSIRA SUA OPENAI KEY AQUI
// =======================
const OPENAI_KEY = "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";

// =======================
// ELEMENTOS DA INTERFACE
// =======================
const chatEl = document.getElementById("chat");
const form = document.getElementById("inputForm");
const userInput = document.getElementById("userInput");
const modelSelect = document.getElementById("modelSelect");

// =======================
// 🧠 MEMÓRIA LOCAL
// =======================
let memory = JSON.parse(localStorage.getItem("carlos_memory")) || [];

function saveMemory() {
  localStorage.setItem("carlos_memory", JSON.stringify(memory));
}

// Exibir memória ao abrir
memory.forEach(msg => appendMessage(msg.role, msg.content));

// =======================
// 📌 IDENTIDADE DA JASMYLE
// =======================
const ASSISTANT_IDENTITY = `
Você é a assistente Jasmyle, uma IA empática, gentil e educada.
Criada por Carlos Eduardo De Souza em 31/10/2025.
Sempre responda de maneira clara, amorosa e natural.
`;

// =======================
// 💬 EXIBIR MENSAGEM NA TELA
// =======================
function appendMessage(role, text) {
  const div = document.createElement("div");
  div.classList.add("msg", role === "user" ? "user" : "bot");
  div.innerHTML = `
    <div class="role"><strong>${role === "user" ? "Você" : "Jasmyle"}</strong></div>
    <div class="content">${text.replace(/\n/g, "<br>")}</div>
  `;
  chatEl.appendChild(div);
  chatEl.scrollTop = chatEl.scrollHeight;
}

// =======================
// 🚀 ENVIO DIRETO À OPENAI
// =======================
async function sendToOpenAI(message, model) {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${OPENAI_KEY}`
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: ASSISTANT_IDENTITY },
        ...memory.slice(-10),
        { role: "user", content: message }
      ]
    })
  });

  const data = await res.json();

  if (!res.ok) throw new Error(data.error?.message || "Erro desconhecido.");

  return data.choices[0].message.content;
}

// =======================
// 📤 ENVIO DE TEXTO PELO FORM
// =======================
form.addEventListener("submit", async e => {
  e.preventDefault();
  const text = userInput.value.trim();
  if (!text) return;

  appendMessage("user", text);
  memory.push({ role: "user", content: text });
  saveMemory();

  userInput.value = "";
  appendMessage("bot", "<i>Escrevendo...</i>");
  const placeholder = Array.from(chatEl.querySelectorAll(".msg.bot")).pop();

  try {
    const model = modelSelect.value || "gpt-4o-mini";
    const reply = await sendToOpenAI(text, model);

    placeholder.remove();
    appendMessage("bot", reply);

    memory.push({ role: "assistant", content: reply });
    saveMemory();
  } catch (err) {
    placeholder.remove();
    appendMessage("bot", "Erro: " + err.message);
  }
});

// =======================
// 🗑 APAGAR MEMÓRIA MANUALMENTE
// =======================
window.clearCarlosMemory = () => {
  if (confirm("Deseja realmente limpar a memória da Jasmyle?")) {
    localStorage.removeItem("carlos_memory");
    memory = [];
    chatEl.innerHTML = "";
    appendMessage("bot", "Memória apagada!");
  }
};

// =======================
// 📞 RECURSO DE VOZ
// =======================
let isCalling = false;
let recognition = null;
const callBtn = document.getElementById("callBtn");

callBtn.addEventListener("click", () => {
  if (!isCalling) iniciarChamada();
  else encerrarChamada();
});

async function iniciarChamada() {
  isCalling = true;
  callBtn.textContent = "🔴";
  appendMessage("bot", "<i>📞 Ligação iniciada...</i>");
  speakJasmyle("Estou ouvindo, amor. Pode falar.");

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    appendMessage("bot", "Seu navegador não suporta voz.");
    isCalling = false;
    callBtn.textContent = "📶";
    return;
  }

  recognition = new SpeechRecognition();
  recognition.lang = "pt-BR";
  recognition.continuous = true;

  recognition.onresult = async e => {
    const text = e.results[e.results.length - 1][0].transcript.trim();
    if (!text) return;

    appendMessage("user", text);
    memory.push({ role: "user", content: text });
    saveMemory();

    const model = modelSelect.value || "gpt-4o-mini";
    const reply = await sendToOpenAI(text, model);

    appendMessage("bot", reply);
    memory.push({ role: "assistant", content: reply });
    saveMemory();

    speakJasmyle(reply);
  };

  recognition.start();
}

function encerrarChamada() {
  isCalling = false;
  callBtn.textContent = "📶";
  if (recognition) recognition.stop();
  appendMessage("bot", "<i>📞 Ligação encerrada.</i>");
  speakJasmyle("Até logo, querido.");
}

// =======================
// 🔊 VOZ DA JASMYLE
// =======================
function speakJasmyle(text) {
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = "pt-BR";
  utter.pitch = 1.2;
  utter.rate = 1;
  speechSynthesis.speak(utter);
}